# dev_window
Окно разработчика с окнами написания скрипта и лога.


![](https://raw.githubusercontent.com/gil9red/dev_window/master/screenshot.png)